import fs from 'fs';

// BEGIN
export async function watch(filepath, interval, callback) {
    let lastModifiedTime = 0;
  
    const checkFile = () => {
        fs.stat(filepath, (err, stats) => {
            if (err) {
                clearInterval(timer);
                callback(err);
                return;
            }
    
            if (stats.mtimeMs > lastModifiedTime) {
                lastModifiedTime = stats.mtimeMs;
                callback(null);
            }
        });
    };
    const timer = setInterval(checkFile, interval);
    return timer;
};
export default watch;
// END
