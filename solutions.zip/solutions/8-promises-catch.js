import fsp from 'fs/promises';
import fs from 'fs';
// BEGIN
export async function touch(filePath) {
    try {
        await fs.promises.access(filePath, fs.constants.F_OK); // Проверяем существование файла
    } catch (error) {
        if (error && error.code === 'ENOENT') {
            // Файл не существует, создаем его
            await fs.promises.writeFile(filePath, '');
        } else {
            throw error; // Пробрасываем ошибку, если что-то пошло не так
        }
    }
};
// END