import fs from 'fs';

// BEGIN
async function write(filename, data, callback) {
    try {
      await fs.promises.writeFile(filename, data);
      callback();
    } catch (error) {
      console.error('Ошибка:', error);
    }
};
export default write;
// END