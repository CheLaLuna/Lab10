import fs from 'fs';

// BEGIN
async function compareFileSizes(filepath1, filepath2, callback) {
    try {
      const stats1 = await fs.promises.stat(filepath1);
      const stats2 = await fs.promises.stat(filepath2);
      
      const result = Math.sign(stats1.size - stats2.size);
      callback(null, result);
    } catch (error) {
      callback(error, null);
    };
};
export { compareFileSizes };
// END