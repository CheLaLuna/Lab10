import fs from 'fs';

// BEGIN
async function print(filename){
    try {
      const data = await fs.promises.readFile(filename, 'utf-8');
      console.log(data);
    } catch (error) {
        console.error('Ошибка:', error);
    };
};
export default print;
// END
