import fsp from 'fs/promises';

// BEGIN
export async function reverse(filePath) {
    try {
        const data = await fsp.readFile(filePath, 'utf8');
        const lines = data.trim().split('\n').reverse().join('\n');
        await fsp.writeFile(filePath, lines);
        console.log('Успешно.');
    } catch (error) {
        console.error('Ошибка:', error);
    }
};
export default reverse;
// END